# reactive-programming-using-reactor
This project has the necessary code for the reactive programming course using Project Reactor

## Swagger-UI

-   Check the following [link](http://localhost:8080/movies/swagger-ui.html) for swagger.
