package com.learnreactiveprogramming.functional;

public class FunctionalExample {
}
