package com.learnreactiveprogramming.imperative;

public class ImperativeExample {
}
